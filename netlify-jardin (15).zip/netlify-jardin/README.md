# 🌿 Jardín Escondido - Sistema de Gestión

## 📦 Contenido de esta carpeta

| Archivo | URL en Netlify | Descripción | Quién lo usa |
|---------|----------------|-------------|--------------|
| `index.html` | tudominio.netlify.app/ | Sistema principal completo | Solo Admin |
| `meseros.html` | tudominio.netlify.app/meseros | App para tomar pedidos | Meseros y Admin |
| `cocina.html` | tudominio.netlify.app/cocina | Pantalla de preparación | Cocina y Admin |

---

## 🆕 Todo integrado en el Sistema Principal

El sistema ahora incluye TODOS los módulos:

### 🌿 Jardín de Eventos
- Cotizaciones, calendario, clientes, proveedores

### 🍽️ Restaurante
- Dashboard, órdenes en vivo, menú, recetas, insumos, inventario

### 💰 Contabilidad
- Vista consolidada, contabilidad por área, registro de gastos

### 🧮 Herramientas
- Cotizador rápido de eventos
- Calculadora de costos de platillos
- Calculadora de rentabilidad
- Punto de equilibrio

### ⚙️ Administración
- Gestión de usuarios (crear, editar, activar/desactivar)
- Gestión de órdenes (ver, eliminar)
- Limpieza de datos por colección

---

## 🚀 INSTRUCCIONES DE INSTALACIÓN

### Paso 1: Subir a Netlify

1. Ve a [netlify.com](https://app.netlify.com) e inicia sesión
2. Arrastra esta carpeta completa al área de "Deploy"
3. Espera a que termine el deploy
4. Copia tu URL (ej: `random-name.netlify.app`)

### Paso 2: Configurar tu primer usuario Admin

1. Abre `tudominio.netlify.app` en el navegador
2. Inicia sesión con tu cuenta de Firebase
3. Click en **"Crear mi perfil como Admin"**
4. ¡Listo! Ya eres administrador

### Paso 3: Configurar reglas de seguridad en Firebase

1. Ve a [Firebase Console](https://console.firebase.google.com)
2. Selecciona tu proyecto "jardin-escondido"
3. Ve a **Firestore Database** → **Reglas**
4. Borra todo y pega esto:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function getUserData() {
      return get(/databases/$(database)/documents/usuarios/$(request.auth.uid)).data;
    }
    
    function isAdmin() {
      return isAuthenticated() && getUserData().rol == 'admin';
    }
    
    function isMesero() {
      return isAuthenticated() && getUserData().rol in ['admin', 'mesero'];
    }
    
    function isCocina() {
      return isAuthenticated() && getUserData().rol in ['admin', 'cocina'];
    }
    
    match /usuarios/{userId} {
      allow read: if isAuthenticated() && 
        (request.auth.uid == userId || isAdmin());
      allow create, update, delete: if isAdmin();
    }
    
    match /ordenesRestaurante/{ordenId} {
      allow read: if isAuthenticated();
      allow create: if isMesero();
      allow update: if isAuthenticated();
      allow delete: if isAdmin();
    }
    
    match /productos/{productoId} {
      allow read: if isAuthenticated();
      allow create, update, delete: if isAdmin();
    }
    
    match /cotizaciones/{cotizacionId} {
      allow read, write: if isAdmin();
    }
    
    match /gastos/{gastoId} {
      allow read, write: if isAdmin();
    }
    
    match /{collection}/{docId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
  }
}
```

5. Click en **"Publicar"**

### Paso 4: Crear usuarios para tu equipo

1. Ve a `tudominio.netlify.app/admin`
2. Inicia sesión con tu cuenta admin
3. Click en **"➕ Nuevo Usuario"**
4. Crea usuarios con los roles apropiados:
   - **Meseros**: rol `mesero`
   - **Cocina**: rol `cocina`

---

## 🎭 ROLES Y PERMISOS

| Rol | Sistema Principal | Admin | Meseros | Cocina |
|-----|------------------|-------|---------|--------|
| **admin** | ✅ | ✅ | ✅ | ✅ |
| **mesero** | ❌ | ❌ | ✅ | ❌ |
| **cocina** | ❌ | ❌ | ❌ | ✅ |

---

## 📱 URLs para tu equipo

Una vez configurado, comparte estas URLs:

- **Meseros** (celular): `tudominio.netlify.app/meseros`
- **Cocina** (tablet/pantalla): `tudominio.netlify.app/cocina`
- **Admin**: `tudominio.netlify.app/admin`

---

## 🔧 Funcionalidades

### Sistema Principal (`index.html`)
- Cotizaciones de eventos
- Calendario de eventos
- Gestión de clientes
- Control de gastos
- Menú y productos
- Inventario

### App Meseros (`meseros.html`)
- Ver mesas disponibles/ocupadas
- Tomar pedidos
- Agregar tiempos a órdenes existentes
- Ver estado de sus órdenes

### Pantalla Cocina (`cocina.html`)
- Ver órdenes pendientes en tiempo real
- Marcar órdenes como "preparando" y "listo"
- Notificaciones de nuevas órdenes
- Historial del día

### Panel Admin (`admin.html`)
- Crear/editar usuarios
- Asignar roles
- Eliminar datos de prueba
- Ver estadísticas

---

## ⚠️ Solución de problemas

### "Permission denied"
- Verifica que publicaste las reglas de Firestore
- Verifica que tu usuario tenga el rol correcto

### No puedo entrar al sistema principal
- Solo usuarios con rol `admin` pueden acceder
- Crea tu perfil de admin primero

### Las órdenes no llegan a cocina
- Verifica que el mesero tenga rol `mesero` o `admin`
- Verifica conexión a internet

---

## 📞 Soporte

Si tienes problemas:
1. Revisa la consola del navegador (F12)
2. Verifica las reglas de Firebase
3. Asegúrate de que los usuarios tengan roles asignados
